<?php

error_reporting(0);

$botToken = '^^TOKEN^^';

$dbUserName = '^^DBuser^^';

$dbPassword = '^^DBpassword^^'; 

$dbName = '^^DBname^^';

$botUrl = '^^url^^'; 

$admin = '^^admin^^';